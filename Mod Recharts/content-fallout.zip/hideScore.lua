function onCreate()
    -- Hide the score, misses, and accuracy
    setProperty('scoreTxt.visible', false)  -- Hides the score text
    setProperty('timeTxt.visible', false)   -- Hides the timer text (optional)
    setProperty('timeBar.visible', false)   -- Hides the timer bar (optional)
end