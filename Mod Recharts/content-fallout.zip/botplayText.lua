function onUpdate()

setTextString("botplayTxt", "Too lazy to play it myself")


end