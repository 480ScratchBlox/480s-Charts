-- Black screen on song countdown and toggle using 'Camera Switch' event
function onCreatePost()
    -- Set the initial black screen (hide HUD and gameplay)
    setProperty('camHUD.alpha', 0)
    setProperty('camGame.alpha', 0)
end

function onCountdownTick(counter)
    -- Ensure the black screen persists during the countdown
    if counter < 4 then
        setProperty('camHUD.alpha', 0)
        setProperty('camGame.alpha', 0)
    end
end

function onEvent(name, value1, value2)
    if name == 'Camera Switch' then
        if value2 == 'on' then
            -- Turn on the visibility of camHUD and camGame
            doTweenAlpha('camHUDon', 'camHUD', 1, tonumber(value1), 'linear')
            doTweenAlpha('camGameon', 'camGame', 1, tonumber(value1), 'linear')
        elseif value2 == 'off' then
            -- Turn off the visibility of camHUD and camGame
            doTweenAlpha('camHUDOff', 'camHUD', 0, tonumber(value1), 'linear')
            doTweenAlpha('camGameOff', 'camGame', 0, tonumber(value1), 'linear')
        end
    end
end
