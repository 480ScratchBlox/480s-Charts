function onCreate()
    if getPropertyFromClass('ClientPrefs', 'downScroll') then
        close(true) -- Disable the script entirely when Downscroll is on
        return
    end

    -- Continue as usual if Downscroll is off
    setProperty('scoreTxt.visible', false)
    setProperty('healthBar.visible', false)
    setProperty('healthBarBG.visible', false)
    setProperty('iconP1.visible', false)
    setProperty('iconP2.visible', false)
end