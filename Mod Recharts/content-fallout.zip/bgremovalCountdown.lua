function onCreate()
    -- Create the black background sprite
    makeLuaSprite('bgremovalhehe', nil, -2500, -1200)
    makeGraphic('bgremovalhehe', 5000, 5000, '000000') -- Black background by default
    addLuaSprite('bgremovalhehe', false) -- Add the sprite to the game
    scaleObject('bgremovalhehe', 5, 5) -- Scale to fullscreen size
    setScrollFactor('bgremovalhehe', 0, 0) -- Ensure it stays in place when scrolling
    setProperty('bgremovalhehe.alpha', 1) -- Background visible during countdown

    -- Set Boyfriend to be invisible during the countdown
    setProperty('boyfriend.alpha', 0) -- Invisible
end

function onCountdownTick(counter)
    -- Ensure black background and Boyfriend's invisibility during countdown
    if counter < 4 then
        setProperty('bgremovalhehe.alpha', 1) -- Keep black background visible
        setProperty('boyfriend.alpha', 0) -- Keep Boyfriend invisible
    else
        setProperty('bgremovalhehe.alpha', 0) -- Hide background after countdown
        -- Do not change Boyfriend's visibility; handled by events
    end
end

-- Event hooks for black background and Boyfriend visibility
function onEvent(name, value1, value2)
    if name == 'bgremovalhehe' then
        -- Toggle background
        if value1 == '1' then
            setProperty('bgremovalhehe.color', getColorFromHex('ffffff')) -- Set to white
            setProperty('bgremovalhehe.alpha', 1) -- Show background
        elseif value1 == '2' then
            setProperty('bgremovalhehe.color', getColorFromHex('000000')) -- Set to black
            setProperty('bgremovalhehe.alpha', 1) -- Show background
        elseif value1 == '0' then
            setProperty('bgremovalhehe.alpha', 0) -- Hide background
        end
    end

    if name == 'BF Fade' then
        -- Control Boyfriend's visibility
        local duration = tonumber(value1) or 0
        if duration < 0 then duration = 0 end

        local targetAlpha = tonumber(value2) or 1 -- Default to visible if not provided
        if duration == 0 then
            -- Instantly set Boyfriend's visibility
            setProperty('boyfriend.alpha', targetAlpha)
            setProperty('iconP1.alpha', targetAlpha)
        else
            -- Gradually fade Boyfriend's visibility
            doTweenAlpha('BFFadeEventTween', 'boyfriend', targetAlpha, duration, 'linear')
            doTweenAlpha('iconP1FadeEventTween', 'iconP1', targetAlpha, duration, 'linear')
        end
    end
end
